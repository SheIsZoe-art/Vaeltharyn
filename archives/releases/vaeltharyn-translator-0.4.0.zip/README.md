# Traducteur Vaeltharyn

Créateur : **SheIsZoe**.

Plugin 0.4.0 ; corpus 1.5.0 ; traduction entre français, anglais et Vaeltharyn.

Le dossier `skills/translate-vaeltharyn/` contient les instructions, la recherche lexicale et le corpus autonome. Il comprend les 111 nouvelles fiches de son, corps et images. Les ajouts linguistiques restent des propositions selon les statuts de leurs fiches.

Les URL GitHub gardent le nom réel du compte du dépôt pour préserver les références. La fiche affichée par un service hôte peut dépendre de son identité éditrice, distincte des métadonnées du paquet.

Voir `skills/translate-vaeltharyn/references/corpus/LICENSE.md` pour la licence et les attributions tierces.
